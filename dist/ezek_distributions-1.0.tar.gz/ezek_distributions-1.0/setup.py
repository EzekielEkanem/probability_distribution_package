from setuptools import setup

setup(name='ezek_distributions',
      version='1.0',
      description='Gaussian and Binomial distributions',
      packages=['ezek_distributions'],
      author = 'Ezekiel Ekanem',
      author_email = "ezekiel.een111@gmail.com",
      zip_safe=False)
